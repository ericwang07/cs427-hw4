#pragma once

enum class Outcome { SouthWin, NorthWin, Tie };
